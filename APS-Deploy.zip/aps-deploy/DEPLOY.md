# APS — Avid Parking Systems · Deployment Guide

## Deploy to Netlify (Free, ~5 minutes)

### Step 1 — Create a free Netlify account
Go to **netlify.com** and sign up (free tier is enough).

---

### Step 2 — Deploy the app

**Option A — Drag and Drop (easiest)**
1. Open the Netlify dashboard
2. Click **"Add new site"** → **"Deploy manually"**
3. Drag the entire **`aps-deploy`** folder onto the upload area
4. Netlify gives you a URL like `https://your-site-name.netlify.app` ✓

**Option B — GitHub (for ongoing updates)**
1. Push this folder to a GitHub repo
2. In Netlify: **"Add new site"** → **"Import from Git"** → connect your repo
3. Build command: *(leave blank)*  
   Publish directory: `.`
4. Deploy — auto-deploys on every push ✓

---

### Step 3 — Set Square environment variables (recommended for production)

In your Netlify dashboard:
1. **Site Settings** → **Environment variables** → **Add variable**
2. Add these three variables:

| Variable Name | Value |
|---|---|
| `SQUARE_ACCESS_TOKEN` | Your Square Production Access Token (from developer.squareup.com) |
| `SQUARE_LOCATION_ID` | Your Square Location ID |
| `SQUARE_SANDBOX` | `false` (use `true` for testing) |

3. Re-deploy (or trigger a new deploy)

> **Why this matters:** With env vars set, your Square access token lives only on the server — it's never visible in the browser. Without env vars, the token entered in APS Settings is sent with each API call (still encrypted via HTTPS, but better practice to use env vars in production).

---

### Step 4 — Connect Square in APS

1. Open your deployed APS URL (e.g. `https://your-site.netlify.app`)
2. Go to **Square Payments** in the sidebar
3. Enter your Square credentials:
   - **Application ID** — from developer.squareup.com → Your App → Credentials
   - **Location ID** — from developer.squareup.com → Your App → Locations
   - **Access Token** — from developer.squareup.com → Your App → Credentials
   - **Square Terminal Device ID** *(optional)* — from Square Dashboard → Devices
4. Toggle **Sandbox** off for production
5. Click **Connect Square**

> Once connected on HTTPS, the **Square Web Payments SDK** loads automatically. The ticket payment modal shows a real embedded card form — customers enter their card directly and it tokenizes securely through Square.

---

## What changes on HTTPS vs local

| Feature | Local file:// | Deployed HTTPS |
|---|---|---|
| Square embedded card form | ❌ (SDK blocked) | ✅ Full card entry form |
| Payment Link generation | Via corsproxy.io | Via your own backend (Netlify function) |
| Square Terminal API | Via corsproxy.io | Via your own backend |
| Access token location | In browser (localStorage) | In Netlify env vars (server-only) |
| Square test cards | Same sandbox cards | Same sandbox cards |

---

## Square credentials reference

| Credential | Where to find |
|---|---|
| Application ID | developer.squareup.com → Your App → Credentials tab |
| Location ID | developer.squareup.com → Your App → Locations tab |
| Access Token | developer.squareup.com → Your App → Credentials tab |
| Terminal Device ID | Square Dashboard → Devices → *your terminal* → Device ID |
| Sandbox toggle | developer.squareup.com → top-right mode toggle |

---

## Custom domain (optional)

In Netlify:
1. **Domain management** → **Add custom domain**
2. Point your DNS to Netlify
3. HTTPS certificate is automatic and free (Let's Encrypt)

---

## Updating APS

Drop the new `index.html` into your Netlify site (drag and drop again, or push to GitHub).  
The `netlify.toml` and functions only need to be deployed once.

---

## File structure

```
aps-deploy/
├── index.html                     ← The entire APS app
├── netlify.toml                   ← Netlify routing + security headers
├── package.json                   ← Node deps (Netlify functions only)
├── netlify/
│   └── functions/
│       └── square-proxy.js        ← Secure Square API backend proxy
└── DEPLOY.md                      ← This file
```
