/**
 * APS — Avid Parking Systems
 * Netlify Serverless Function: Square API Proxy
 *
 * Receives Square API requests from the APS frontend and forwards them
 * to Square with the access token. Keeps credentials server-side.
 *
 * Supports:
 *   - POST /api/square-proxy  { action, ...params }
 *
 * Actions:
 *   payment_link       → POST /v2/online-checkout/payment-links
 *   create_payment     → POST /v2/payments  (for card token from Web Payments SDK)
 *   terminal_checkout  → POST /v2/terminals/checkouts
 *   get_terminal       → GET  /v2/terminals/checkouts/:id
 *   list_locations     → GET  /v2/locations
 *   create_invoice     → POST /v2/invoices
 *   publish_invoice    → POST /v2/invoices/:id/publish
 */

const handler = async (event) => {
  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  // CORS headers — allows your deployed APS app to call this function
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // ── Parse request ──────────────────────────────────────────────
  let payload;
  try {
    payload = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON' }) };
  }

  // ── Credentials: env vars take priority over client-sent token ─
  // For production: set SQUARE_ACCESS_TOKEN in Netlify environment variables
  // (Site Settings → Environment variables). Remove it from the frontend.
  // For initial setup: client sends the token in the request body.
  const accessToken = process.env.SQUARE_ACCESS_TOKEN || payload.accessToken;
  const isSandbox   = process.env.SQUARE_SANDBOX === 'true' || payload.sandbox === true;
  const locationId  = process.env.SQUARE_LOCATION_ID || payload.locationId;

  if (!accessToken) {
    return { statusCode: 401, headers, body: JSON.stringify({ error: 'Square access token not configured.' }) };
  }

  const sqBase = isSandbox
    ? 'https://connect.squareupsandbox.com'
    : 'https://connect.squareup.com';

  const sqHeaders = {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
    'Square-Version': '2024-01-18',
  };

  // ── Route to the correct Square endpoint ──────────────────────
  const { action } = payload;
  let sqPath, sqMethod, sqBody;

  try {
    switch (action) {

      // ── Payment Link (hosted checkout) ────────────────────────
      case 'payment_link': {
        sqPath   = '/v2/online-checkout/payment-links';
        sqMethod = 'POST';
        sqBody   = {
          idempotency_key: payload.idempotency_key,
          quick_pay: {
            name:         payload.description || 'Parking Payment',
            price_money:  { amount: payload.amount_cents, currency: 'USD' },
            location_id:  locationId || payload.location_id,
          },
          checkout_options: { ask_for_shipping_address: false },
        };
        break;
      }

      // ── Card payment (from Web Payments SDK token) ────────────
      case 'create_payment': {
        sqPath   = '/v2/payments';
        sqMethod = 'POST';
        sqBody   = {
          source_id:       payload.source_id,   // token from card.tokenize()
          idempotency_key: payload.idempotency_key,
          amount_money:    { amount: payload.amount_cents, currency: 'USD' },
          location_id:     locationId || payload.location_id,
          note:            payload.note || 'APS Parking Payment',
          reference_id:    payload.reference_id,
          autocomplete:    true,
        };
        break;
      }

      // ── Square Terminal checkout ──────────────────────────────
      case 'terminal_checkout': {
        sqPath   = '/v2/terminals/checkouts';
        sqMethod = 'POST';
        sqBody   = {
          idempotency_key: payload.idempotency_key,
          checkout: {
            amount_money:   { amount: payload.amount_cents, currency: 'USD' },
            note:           payload.note || 'Parking',
            device_options: {
              device_id:           payload.device_id,
              skip_receipt_screen: false,
              tip_settings:        { allow_tipping: false },
            },
          },
        };
        break;
      }

      // ── Get terminal checkout status ──────────────────────────
      case 'get_terminal': {
        sqPath   = `/v2/terminals/checkouts/${payload.checkout_id}`;
        sqMethod = 'GET';
        sqBody   = null;
        break;
      }

      // ── List locations ────────────────────────────────────────
      case 'list_locations': {
        sqPath   = '/v2/locations';
        sqMethod = 'GET';
        sqBody   = null;
        break;
      }

      // ── Create invoice ────────────────────────────────────────
      case 'create_invoice': {
        sqPath   = '/v2/invoices';
        sqMethod = 'POST';
        sqBody   = {
          idempotency_key: payload.idempotency_key,
          invoice: {
            location_id:      locationId || payload.location_id,
            primary_recipient: { customer_id: payload.customer_id || undefined },
            delivery_method:  'EMAIL',
            title:            payload.title || 'Monthly Parking Invoice',
            description:      payload.description || '',
            payment_requests: [{
              request_type:          'BALANCE',
              due_date:              payload.due_date,
              automatic_payment_source: payload.autopay ? 'CARD_ON_FILE' : 'NONE',
            }],
            invoice_number:   payload.invoice_number,
          },
        };
        // Remove undefined fields
        if (!sqBody.invoice.primary_recipient.customer_id) {
          delete sqBody.invoice.primary_recipient;
        }
        break;
      }

      // ── Publish (send) invoice ────────────────────────────────
      case 'publish_invoice': {
        sqPath   = `/v2/invoices/${payload.invoice_id}/publish`;
        sqMethod = 'POST';
        sqBody   = {
          idempotency_key: payload.idempotency_key,
          version:         payload.version || 0,
        };
        break;
      }

      default:
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: `Unknown action: ${action}` }),
        };
    }

    // ── Make the Square API call ───────────────────────────────
    const resp = await fetch(sqBase + sqPath, {
      method:  sqMethod,
      headers: sqHeaders,
      body:    sqBody ? JSON.stringify(sqBody) : undefined,
    });

    const data = await resp.json();

    return {
      statusCode: resp.status,
      headers,
      body: JSON.stringify(data),
    };

  } catch (err) {
    console.error('[APS Square Proxy Error]', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message }),
    };
  }
};

module.exports = { handler };
